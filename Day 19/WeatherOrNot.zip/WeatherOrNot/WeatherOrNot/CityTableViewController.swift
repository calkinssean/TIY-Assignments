//
//  CityTableViewController.swift
//  WeatherOrNot
//
//  Created by Sean Calkins on 2/25/16.
//  Copyright © 2016 Dape App Productions LLC. All rights reserved.
//

import UIKit
import CoreLocation

class CityTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, WeatherAppProtocol {
    @IBOutlet weak var cityTableView: UITableView!
    @IBOutlet weak var citySearchTextField: UITextField!
    
    var cities = [City]()
    var currentCity = City()
    var weatherArray = [Weather]()
    var apiClient: APIController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        apiClient = APIController(delegate: self)
        
        
    }
    @IBAction func citySearchButtonTapped(sender: UIButton) {
        geocoding(citySearchTextField.text!) { (latitude: Double, longitude: Double) in
            self.apiClient?.getWeatherJSON("\(latitude),\(longitude)")

        }
    }
    
    
    
    
    func geocoding(location: String, completion: (Double, Double) -> ()) {
        CLGeocoder().geocodeAddressString(location) { (placemarks, error) in
            if placemarks?.count > 0 {
                let placemark = placemarks?[0]
                let location = placemark!.location
                let coordinate = location?.coordinate
                completion((coordinate?.latitude)!, (coordinate?.longitude)!)
            }
        }
    }
    
    
   
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cities.count
    }
    
    
    func createCityObject() {
        
    }
    func segueCityToTableViewArray() {
        
    }
    func passWeatherArray(weatherArray: [Weather]) {
        self.weatherArray = weatherArray
        let c = self.currentCity
        c.weatherArray = weatherArray
        cities.append(c)
        self.weatherArray.removeAll()
        print(self.cities.count)
        self.cityTableView.reloadData()
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        self.currentCity = cities[indexPath.row]
        let currentWeather = currentCity.weatherArray.first
        let cell = tableView.dequeueReusableCellWithIdentifier("cityCell") as! CityTableViewCell
        cell.cityTemperatureLabel.text = "\(currentWeather?.temperatureMin)°F"
        return cell
    }
    
    
    
}

