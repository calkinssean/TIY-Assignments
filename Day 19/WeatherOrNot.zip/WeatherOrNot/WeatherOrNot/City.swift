//
//  City.swift
//  WeatherOrNot
//
//  Created by Sean Calkins on 2/25/16.
//  Copyright © 2016 Dape App Productions LLC. All rights reserved.
//

import UIKit

class City {
    var cityName: String = ""
    var longitude: Double = 0.0
    var latitude: Double = 0.0
    var weatherArray = [Weather]()
}