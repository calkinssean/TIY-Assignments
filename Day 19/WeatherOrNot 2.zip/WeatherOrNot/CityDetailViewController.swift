//
//  CityDetailViewController.swift
//  WeatherOrNot
//
//  Created by Sean Calkins on 2/25/16.
//  Copyright © 2016 Dape App Productions LLC. All rights reserved.
//

import UIKit

class CityDetailViewController: UIViewController {
    
    @IBOutlet weak var cityNameLabel: UILabel!
    
    @IBOutlet weak var iconImage: UIImageView!
    
    var detailCity: City?
    override func viewDidLoad() {
        super.viewDidLoad()
        iconImage.image = UIImage(named: "snow")
        self.cityNameLabel.text = detailCity?.formatted_address
        print(detailCity?.icon)
        print(detailCity?.summary)
        }

}
